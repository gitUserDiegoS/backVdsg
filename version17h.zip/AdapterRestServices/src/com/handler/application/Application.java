package com.handler.application;

import javax.ws.rs.ApplicationPath;

import org.glassfish.jersey.jackson.JacksonFeature;
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.server.filter.RolesAllowedDynamicFeature;

@ApplicationPath("rest")
public class Application extends ResourceConfig {
    public Application() {
        packages("com.handler");
        register(JacksonFeature.class);
        register(RolesAllowedDynamicFeature.class);
    }
}
