//package com.handler.pojo;
//
//import java.sql.CallableStatement;
//import java.sql.Connection;
//import java.sql.SQLException;
//
//import oracle.ucp.jdbc.PoolDataSource;
//import oracle.ucp.jdbc.PoolDataSourceFactory;
//
//public class PbaConectaDataSource {
//
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//
//		try {
//			// crea la instancia en el pool
//			PoolDataSource pds = PoolDataSourceFactory.getPoolDataSource();
//
//			pds.setConnectionFactoryClassName("oracle.jdbc.pool.OracleDataSource");
//			pds.setURL("jdbc:oracle:thin:@localhost:1521:xe");
//			pds.setUser("system");
//			pds.setPassword("oraDiego10");
//
//			// Pripiedades del pool.
//
//			pds.setInitialPoolSize(5);
//
//			Connection conn = pds.getConnection();
//
//			System.out.println("\nConnection obtained from " + "UniversalConnectionPool\n");
//
////				llamada al procedimiento almacenado
//			CallableStatement cst = conn.prepareCall("{call ObtenerDatosCatalogo (?,?)}");
//
////				parametro del procedimiento almacenado
//			int id = 1;
//			cst.setInt(1, id);
//
////				definicion de los tipos de parametros de salida
//			cst.registerOutParameter(2, java.sql.Types.VARCHAR);
//
////				ejecucion del procedimiento
//			cst.execute();
//
////				obtencion de la salida del procedimiento
//
//			String endpoint = cst.getString(2);
//
//			System.out.println("ESto es lo que se obtiene del procedimiento---->operacion-->endpoint-->" + endpoint);
//
//			conn.close();
//			conn = null;
//
//			System.out.println("Connection returned to the " + "UniversalConnectionPool\n");
//
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
//
//}
