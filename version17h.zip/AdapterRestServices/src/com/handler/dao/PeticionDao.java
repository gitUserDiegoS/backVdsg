package com.handler.dao;

import java.sql.SQLException;
import java.util.Date;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import com.handler.client.AccesoCliente;
import com.handler.procedures.Consulta;

public class PeticionDao {

	private String operation;

	public String getOperation() {
		return operation;
	}

	public void setOperation(String operation) {
		this.operation = operation;
	}

	public PeticionDao() {
		super();
	}

	/**
	 * Metodo que devuelve respuesta de endpoint segun operacion
	 * 
	 * @param payloadFull
	 * @return
	 * @throws Exception, SQLException
	 */
	public String handleRequest(String payloadFull) throws Exception, SQLException {

		String enrutador = "";
		try {

			if (payloadFull.isEmpty()) {

				throw new Exception("No se indica ningun payload a enviar");

			}

			setOperation(tipoOperacion(payloadFull));

			System.out.println("Esto es lo que estoy obteniendo desde clase---->" + getOperation());

			enrutador = new Consulta().leerhcweb(getOperation());

			System.out.println("Ruta a utilizar de consumo (hcweb) --->" + enrutador);

			// obtencion de respuesta segun endpoint
			String respuesta = new AccesoCliente().envioDePayloadpost(enrutador, payloadFull);
			return respuesta;
		} catch (SQLException e) {

			throw new SQLException(e.getMessage());

		}

	}

	/**
	 * Metodo que recibe payload completo para tratar la etiqueta header del json
	 * 
	 * @param payloadHeader
	 * @return operation, para determinar el endpoint a enrutar
	 * @throws Exception
	 */
	public String tipoOperacion(String payloadHeader) throws Exception {

		System.out.println("Payload recibido --->" + payloadHeader);

		// convierte string a json element
		JsonElement result = parseObjectToJsonElement(payloadHeader);

		// Obtencion header del payload recibido

		setOperation(result.getAsJsonObject().get("Header").getAsJsonObject().get("operation").getAsString());

		return operation;
	}

	/**
	 * Metodo que pasa payload completo JsonElement
	 * 
	 * @param payloadGeneric
	 * @return hashmap generalHash
	 */
	public JsonElement parseObjectToJsonElement(String payloadGeneric) {
		JsonElement root = null;
		try {
			root = new JsonParser().parse(payloadGeneric);

		} catch (JsonSyntaxException e) {
			throw new JsonSyntaxException(e.getMessage());
		}

		return root;
	}

	/**
	 * Metodo que trata el mensaje de la excepcion, si viene con comillas se quitan
	 * para devolver con formato el mensaje
	 * 
	 * @param exc
	 * @return string formateado
	 */
	public String manageException(String exc) {
		String msg = "";
		if (exc.contains("\"")) {
			msg = exc.replace("\"", " ").trim();

		} else {
			msg = exc;

		}

		return msg;
	}

	/**
	 * Metodo que registra la trazabilidad del evento en base de datos
	 * 
	 * @param payload
	 * @param tipoDeEvento
	 * @return
	 * @throws Exception
	 */
	public boolean registrarEvento(String payload, String msgResp, String msg, boolean tipoDeEvento) throws Exception {
		boolean satisfactorio = false;
		try {

			// si es true, registra traza flujo normal
			if (tipoDeEvento == true) {

				new Consulta().inserthcwebDos(Integer.valueOf(AccesoCliente.getEstadoApersistir()),
						new Date().toString(), new PeticionDao().tipoOperacion(payload), payload, msgResp);

			} else {// sino registra flujo con excepcion
				new Consulta().inserthcwebDos(500, new Date().toString(),
						payload.isEmpty() ? "No registra" : new PeticionDao().tipoOperacion(payload),
						payload.isEmpty() ? "No resgistra" : payload,
						"{\r\n" + "    \"RestConsultarSKUResp\": {\r\n" + "        \"RespuestaCodigo\": \"1\",\r\n"
								+ "        \"RespuestaMensaje\": \"" + msg + "\"\r\n" + "    }\r\n" + "}");

			}

		} catch (NumberFormatException e) {

			throw new NumberFormatException("Number format exception " + e.getMessage());
		} catch (SQLException e) {

			throw new SQLException(e.getMessage());
		}
		return satisfactorio;

	}

}
