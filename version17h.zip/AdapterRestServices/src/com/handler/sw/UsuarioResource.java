package com.handler.sw;

import java.util.Calendar;
import java.util.Date;

import javax.naming.AuthenticationException;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

import com.handler.filter.RestSecurityFilter;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Path("/usuario")
public class UsuarioResource {

	@GET
	@Path("/login")
	public Response authenticateUser(@QueryParam("idApp") String user) {
		try {
			// se valida el dato de ingreso
			String roles = authenticate(user);

			// se genera el token a partir de la validacion hecha
			String token = issueToken(user, roles);

			return Response.ok().header(HttpHeaders.AUTHORIZATION, "Bearer " + token).build();
		} catch (Exception e) {
			return Response.status(Response.Status.UNAUTHORIZED).build();
		}

	}

	private String issueToken(String login, String roles) {
		// calculo de la fecha de expiracion del token
		Date issueDate = new Date();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(issueDate);
		calendar.add(Calendar.MINUTE, 60);
		Date expireDate = calendar.getTime();

		// creacion del token()
		String jwtToken = Jwts.builder().claim("roles", roles).setSubject(login)
//				.setIssuer("http://www.infointernet.es")
				.setExpiration(expireDate)
				.signWith(SignatureAlgorithm.HS512, RestSecurityFilter.KEY)
				.compact();

		return jwtToken;
	}


	private String authenticate(String user) throws AuthenticationException {
		//codigo respectivo para la validacion de sesion
		//Se cuenta con dos usuario de prueba
		if ("1abc3".equals(user)) {
			return "USUARIO";
		} else if ("2bcd4".equals(user)) {
			return "ADMINISTRADOR";
		} else {
			throw new AuthenticationException();
		}

	}
}