package com.handler.security;

import java.security.Principal;

import javax.ws.rs.core.SecurityContext;

import com.handler.bean.IdApplication;

public class MyApplicationSecurityContext implements SecurityContext {
//	private User usuario;original
	private IdApplication usuario;
//	private boolean secure;
//	User usuario
	public MyApplicationSecurityContext(IdApplication usuario, boolean secure) {
		this.usuario = usuario;
//		this.secure = secure;
	}
	
	@Override
	public Principal getUserPrincipal() {
		return usuario;
	}

//	@Override
//	public boolean isUserInRole(String rol) {
//		if (usuario.getRoles() != null) {
//			return usuario.getRoles().contains(rol);
//		}
//		return false;
//	}

	@Override
	public boolean isSecure() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getAuthenticationScheme() {
		return SecurityContext.FORM_AUTH;
	}

	@Override
	public boolean isUserInRole(String role) {
		// TODO Auto-generated method stub
		return false;
	}
}