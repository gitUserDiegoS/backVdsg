package com.handler.bean;

import java.security.Principal;

public class IdApplication implements Principal {

	private String idApp;

	public String getIdApp() {
		return idApp;
	}

	public void setIdApp(String idApp) {
		this.idApp = idApp;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return idApp;
	}

}
