package com.handler.filter;

import java.io.IOException;
import java.security.Key;

import javax.annotation.Priority;
import javax.ws.rs.Priorities;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.Provider;

import com.handler.annotation.Secured;
import com.handler.bean.IdApplication;
import com.handler.security.MyApplicationSecurityContext;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.impl.crypto.MacProvider;


@Provider
@Secured
@Priority(Priorities.AUTHENTICATION)
public class RestSecurityFilter implements ContainerRequestFilter {

	public static final Key KEY = MacProvider.generateKey();

	@Override
	public void filter(ContainerRequestContext requestContext) throws IOException {
		// Recupera la cabecera HTTP Authorization de la petici�n
		String authorizationHeader = requestContext.getHeaderString(HttpHeaders.AUTHORIZATION);

		try {
			// Extrae el token de la cabecera
			String token = authorizationHeader.substring("Bearer".length()).trim();

			// Valida el token utilizando la cadena secreta
			Jws<Claims> claims = Jwts.parser().setSigningKey(KEY).parseClaimsJws(token);

			// Creamos el usuario a partir de la informaci�n del token
//			User usuario = new User(); original
			IdApplication appRequest= new IdApplication();
//			usuario.setUsername(claims.getBody().getSubject()); original
			appRequest.setIdApp(claims.getBody().getSubject());
//			String roles = (String) claims.getBody().get("roles"); original
//			String idRequest = (String) claims.getBody().get("roles");
//			usuario.setRoles(Arrays.asList(roles.split(","))); original

			// Creamos el SecurityContext
//			MyApplicationSecurityContext secContext = new MyApplicationSecurityContext(usuario,
//					requestContext.getSecurityContext().isSecure()); original
			
			MyApplicationSecurityContext secContext = new MyApplicationSecurityContext(appRequest,
					requestContext.getSecurityContext().isSecure());

			// Seteamos el contexto de seguridad
			requestContext.setSecurityContext(secContext);

		} catch (Exception e) {
			requestContext.abortWith(Response.status(Response.Status.UNAUTHORIZED).build());
		}

	}

}
