package com.handler.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;

public class Utils {

	/**
	 * Metodo que obtiene la fecha tipo Date(), para devolverla en formato String
	 * 
	 * @param fechaConvertir
	 * @return
	 */
	public String parseDateToString(Date fechaConvertir) {
		String fechaString;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		fechaString = sdf.format(fechaConvertir);
		return fechaString;
	}

	/**
	 * Metodo que trata el mensaje de la excepcion, si viene con comillas se quitan
	 * para devolver con formato el mensaje
	 * 
	 * @param exc
	 * @return string formateado
	 */
	public String manageException(String exc) {
		String msg = "";
		if (exc.contains("\"")) {
			msg = exc.replace("\"", " ").trim();

		} else {
			msg = exc;

		}

		return msg;
	}

	/**
	 * Metodo que pasa payload completo a JsonElement
	 * 
	 * @param payloadGeneric
	 * @return hashmap generalHash
	 */
	public JsonElement parseObjectToJsonElement(String payloadGeneric) {
		JsonElement root = null;
		try {
			root = new JsonParser().parse(payloadGeneric);

		} catch (JsonSyntaxException e) {
			throw new JsonSyntaxException(e.getMessage());
		}

		return root;
	}
	
	/**
	 * Metodo que obtiene la clase y el metodo en donde se presenta la execpcion
	 * @param nameMethod
	 * @param nameClass
	 * @return
	 */
	public String claseOrigen(String nameMethod, String nameClass) {
		String sMethodName = nameMethod;
		String sClassName = nameClass;
		return "Class - [" + sClassName + "] Metodo - [" + sMethodName + "]";
	}

}
