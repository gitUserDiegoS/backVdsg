package com.handler.client;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class AccesoCliente {

	static String estadoApersistir;

	public static String getEstadoApersistir() {
		return estadoApersistir;
	}

	public static void setEstadoApersistir(String estadoApersistir) {
		AccesoCliente.estadoApersistir = estadoApersistir;
	}

	public String devuelveRespuesta(String ruta) {

		Client client = Client.create();
		System.out.println("endpoint a enrutar ---->" + ruta);
		WebResource resource = client.resource(ruta);

		ClientResponse response = resource.accept("application/json").get(ClientResponse.class);
		String codeStatus = String.valueOf(response.getStatus());
		estadoApersistir = codeStatus;
		if (response.getStatus() != 200) {
			throw new RuntimeException("Fall� : HTTP error code:" + response.getStatus());

		} else {

			String output = response.getEntity(String.class);
			System.out.println("Esto es lo que obtiene--->" + output);

			return output;
		}
	}

	/**
	 * Metodo que envia payload al servicio a enrutar
	 * 
	 * @param ruta
	 * @param payload
	 * @return respuesta del servicio
	 */
	public String envioDePayloadpost(String ruta, String payload) {

		Client client = Client.create();

		WebResource resource = client.resource(ruta);

		String input = payload;

		ClientResponse response = resource.type("application/json").post(ClientResponse.class, input);

		String codeStatus = String.valueOf(response.getStatus());
		estadoApersistir = codeStatus;

		if (response.getStatus() != 200) {
//			Loggerj.logError("fall� response, en acceso a cliente " + codeStatus);
			throw new RuntimeException(
					"Fall� en response del acceso a servicio: "+ruta+" codigo de error HTTP : " + response.getStatus());

		}

		String output = response.getEntity(String.class);
		System.out.println(output);

		return output;

	}

}
