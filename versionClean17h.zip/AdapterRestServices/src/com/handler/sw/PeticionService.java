package com.handler.sw;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

//import org.apache.log4j.BasicConfigurator;
//import org.apache.log4j.LogManager;
//import org.apache.log4j.Logger;
//import org.apache.log4j.BasicConfigurator;
//import org.apache.log4j.Logger;
import org.json.JSONException;

import com.handler.annotation.Secured;
import com.handler.dao.PeticionDao;
import com.handler.pojo.User;
import com.handler.utils.Utils;
//import com.log4j.Loggerj;
import com.log4j.Loggerj;

@Path("/adapter")
public class PeticionService {

	/**
	 * Metodo test get para escribir en logs
	 * 
	 * @return
	 * @throws JSONException
	 */
	@GET
	@Path("/req")
	@Secured
	@Produces({ MediaType.APPLICATION_JSON })
	public Response getUsers() throws JSONException {

		Loggerj.logDebug("Esta es una prueba funcional si enviar clase!!!");

//		LOGGER.info("desde claseeeeeeeeeeee");	
		Loggerj.logDebug(this.getClass().getName(), "Esta es una pruebaaaaaaaaaa enviando clase");

		List<User> users = new ArrayList<>();
		users.add(new User("Diego A"));
		users.add(new User("Diego B"));
		users.add(new User("usuario 3"));
		return Response.status(200).entity(users.toString()).build();
	}

	@POST
	@Path("/request")
	@Produces("application/json")
	@Secured
	@Consumes("application/json")
	public String recibePeticion(String payload) throws Exception {
		String response = "";
		try {

			response = new PeticionDao().handleRequest(payload);
			new PeticionDao().registrarEvento(payload, response, "", 1);

			return response;
		} catch (Exception e) {
			String msg = new Utils().manageException(e.getMessage());
			Loggerj.logError(msg);
			response = new PeticionDao().registrarEvento(payload, "", msg, 0);

			return response;
		}

	}

}
