package com.handler.procedures;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import com.handler.connection.DataSourceHCWEB;
import com.handler.utils.Utils;

public class Consulta {

	public String leerhcweb(String oper) throws SQLException {

		DataSource ds = null;
		Connection conn = null;
		CallableStatement cst = null;

		int operacion = 0;
		String endpoint = "";

		try {
			ds = DataSourceHCWEB.getOracleDataSource();
			conn = ds.getConnection();

			while (conn == null) {
				ds = DataSourceHCWEB.getOracleDataSource();
				conn = ds.getConnection();

			}

//			llamada al procedimiento almacenado

			cst = conn.prepareCall("{call ObtenerDatosCatalogo (?,?)}");

//			parametro del procedimiento almacenado
//			int id = 1;
			cst.setString(1, oper);

//			definicion de los tipos de parametros de salida			
			cst.registerOutParameter(2, java.sql.Types.VARCHAR);

//			ejecucion del procedimiento
			cst.execute();

//			obtencion de la salida del procedimiento			
			endpoint = cst.getString(2);

			System.out.println("ESto es lo que se obtiene del procedimiento---->operacion-->" + operacion
					+ " endpoint-->" + endpoint);

			System.out.println("modular lo que obtiene-->"
					+ new Utils().claseOrigen(new String(Thread.currentThread().getStackTrace()[1].getMethodName()),
							new String(Thread.currentThread().getStackTrace()[1].getClassName())));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("clase " + e.getMessage());

//			Loggerj.logError(e.getMessage());
			throw new SQLException(
					"Error - La operacion no relaciona endpoints o viene vacia  - ref: " + e.getMessage());

//			e.printStackTrace();
		} finally {
			try {
				if (cst != null)
					cst.close();
				if (conn != null)
					conn.close();

			} catch (SQLException ex) {
				System.out.println("Error: " + ex.getMessage());
//				Loggerj.logError(ex.getMessage());
				throw new SQLException("Error - cerrando conexiones - " + ex.getMessage());
			}
		}
		return endpoint;

	}

//	opccion dos de tabla
	public boolean inserthcwebDos(int codigo, String fecha, String operacion, String pointrequest, String pointresponse)
			throws SQLException {

		DataSource ds = null;
		Connection conn = null;
		CallableStatement cst = null;

		boolean satisfactorio = false;

		try {
			ds = DataSourceHCWEB.getOracleDataSource();
			conn = ds.getConnection();

			while (conn == null) {
				ds = DataSourceHCWEB.getOracleDataSource();
				conn = ds.getConnection();

			}

//			llamada al procedimiento almacenado

			cst = conn.prepareCall("{call registratrazados (?,?,?,?,?)}");

//			parametro del procedimiento almacenado
//			int id = 1;
			cst.setInt(1, codigo);
			cst.setString(2, fecha);
			cst.setString(3, operacion);
			cst.setString(4, pointrequest);
			cst.setString(5, pointresponse);

//			ejecucion del procedimiento
			cst.execute();
			satisfactorio = true;

		} catch (SQLException e) {

			System.out.println("Error: " + e.getMessage());
			throw new SQLException("Error - No se realiz� inserci�n en la base de datos - ref: " + e.getMessage());

		} finally {
			try {
				if (cst != null)
					cst.close();
				if (conn != null)
					conn.close();

			} catch (SQLException ex) {
				System.out.println("Error: " + ex.getMessage());
				throw new SQLException("Error cerrando conexiones - " + ex.getMessage());
			}

		}
		return satisfactorio;

	}

	

	public boolean verificarConexion() {
		DataSource ds = null;
		Connection conn = null;
		boolean flag = false;
		try {
			ds = DataSourceHCWEB.getOracleDataSource();
			conn = ds.getConnection();

			if (conn != null) {
				flag = true;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error en conexion: " + e.getMessage());
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("Error cerrando conexion: " + e.getMessage());
			}
		}

		return flag;
	}

}
