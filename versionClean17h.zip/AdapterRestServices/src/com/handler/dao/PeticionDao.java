package com.handler.dao;

import java.sql.SQLException;
import java.util.Date;

import com.google.gson.JsonElement;
import com.handler.client.AccesoCliente;
import com.handler.procedures.Consulta;
import com.handler.utils.Utils;

public class PeticionDao {

	private String operation;

	public String getOperation() {
		return operation;
	}

	public void setOperation(String operation) {
		this.operation = operation;
	}

	public PeticionDao() {
		super();
	}

	/**
	 * Metodo que devuelve respuesta de endpoint segun operacion
	 * 
	 * @param payloadFull
	 * @return
	 * @throws Exception, SQLException
	 */
	public String handleRequest(String payloadFull) throws Exception, SQLException {

		String enrutador = "";
		try {

			if (payloadFull.isEmpty()) {

				throw new Exception("No se indica ningun payload a enviar");

			}

			this.setOperation(tipoOperacion(payloadFull));

			System.out.println("Esto es lo que estoy obteniendo desde clase---->" + getOperation());

			enrutador = new Consulta().leerhcweb(getOperation());

			System.out.println("Ruta a utilizar de consumo (hcweb) --->" + enrutador);

			// obtencion de respuesta segun endpoint
			String respuesta = new AccesoCliente().envioDePayloadpost(enrutador, payloadFull);
//			String respuesta = new AccesoCliente().devuelveRespuesta(enrutador);

			return respuesta;
		} catch (SQLException e) {

			throw new SQLException(e.getMessage());

		}

	}

	/**
	 * Metodo que recibe payload completo para tratar la etiqueta header del json
	 * 
	 * @param payloadHeader
	 * @return operation, para determinar el endpoint a enrutar
	 * @throws Exception
	 */
	public String tipoOperacion(String payloadHeader) throws Exception {

		String devolverOperacion = "";
		System.out.println("Payload recibido --->" + payloadHeader);

		// convierte string a json element
		JsonElement result = new Utils().parseObjectToJsonElement(payloadHeader);

		// Obtencion header del payload recibido

		devolverOperacion = result.getAsJsonObject().get("Header").getAsJsonObject().get("operation").getAsString();

		return devolverOperacion;
	}

	/**
	 * Metodo que registra la trazabilidad del evento en base de datos
	 * 
	 * @param payload
	 * @param tipoDeEvento
	 * @return
	 * @throws Exception
	 */
	public String registrarEvento(String payload, String msgResp, String msg, int tipoDeEvento) throws Exception {

		String responseException = "";
		String operacion="";
		try {
			if (!payload.isEmpty()) {
				operacion = new PeticionDao().tipoOperacion(payload);
				if (operacion.isEmpty() || operacion == null)
					operacion = "No registra operation";

			}

			// cuando tipo de operacion es cero, registra flujo con excepcion
			switch (tipoDeEvento) {
			case 0:

				new Consulta().inserthcwebDos(500, new Utils().parseDateToString(new Date()),
						payload.isEmpty() ? "No registra" : operacion, payload.isEmpty() ? "No registra" : payload,
						"{\r\n" + "    \"RestConsultarSKUResp\": {\r\n" + "        \"RespuestaCodigo\": \"1\",\r\n"
								+ "        \"RespuestaMensaje\": \"" + msg + "\"\r\n" + "    }\r\n" + "}");

				responseException = "{\r\n" + "    \"Rest" + operacion.replaceAll("\\s", "") + "Resp\": {\r\n"
						+ "        \"RespuestaCodigo\": \"1\",\r\n" + "        \"RespuestaMensaje\": \"" + msg
						+ "\"\r\n" + "    }\r\n" + "}";

				break;

			// cuando tipo de operacion es uno, registra flujo normal
			case 1:

				new Consulta().inserthcwebDos(Integer.valueOf(AccesoCliente.getEstadoApersistir()),
						new Utils().parseDateToString(new Date()), operacion, payload, msgResp);
				break;
			}

		} catch (NumberFormatException e) {

			throw new NumberFormatException("Number format exception " + e.getMessage());
		} catch (SQLException e) {

			throw new SQLException(e.getMessage());
		}
		return responseException;

	}

}
