package com.handler.pojo;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import oracle.jdbc.pool.OracleDataSource;

public class PbaSegundoDatasource {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection con = null;

		try {
			OracleDataSource oracleDS = null;
			oracleDS = new OracleDataSource();

			oracleDS.setURL("jdbc:oracle:thin:@localhost:1521:xe");
			oracleDS.setUser("system");
			oracleDS.setPassword("oraDiego10");

			con = oracleDS.getConnection();

			System.out.println("Conexion establecida--->" + con);

//			llamada al procedimiento almacenado
			CallableStatement cst = con.prepareCall("{call ObtenerDatosCatalogo (?,?)}");

//				parametro del procedimiento almacenado
			int id = 1;
			cst.setInt(1, id);

//				definicion de los tipos de parametros de salida
			cst.registerOutParameter(2, java.sql.Types.VARCHAR);

//				ejecucion del procedimiento
			cst.execute();

//				obtencion de la salida del procedimiento

			String endpoint = cst.getString(2);

			System.out.println("ESto es lo que se obtiene del procedimiento---->operacion-->endpoint-->" + endpoint);

			con.close();
			con = null;

			System.out.println("Connection returned to the " + "UniversalConnectionPool\n");

			

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}
	}

}
