package com.handler.connection;

import java.sql.SQLException;

import javax.sql.DataSource;

import oracle.jdbc.pool.OracleDataSource;

public class DataSourceHCWEB {

	public static DataSource getOracleDataSource() throws SQLException {
		OracleDataSource properties = null;
		try {

			properties = new OracleDataSource();
//			properties.setURL("jdbc:oracle:thin:@localhost:1522:xe");
			properties.setURL("jdbc:oracle:thin:@localhost:1521:xe");
			properties.setUser("system");
			properties.setPassword("oraDiego10");

		} catch (SQLException e) {
			throw new SQLException(e.getMessage());
		}
		return properties;
	}
}
