package com.handler.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Connector {

	private Connection conn = null;

	public Connection getConn() {
		return conn;
	}

	public void setConn(Connection conn) {
		this.conn = conn;
	}

	/**
	 * 
	 * metodo para generar conexion 
	 * 
	 * @return
	 * @throws SQLException
	 */
	public Connection Conectar() throws SQLException {

//		cargar driver
		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());

//			conectar con la bd
//			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1531:xe", "system", "oraDiego10");

			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "oraDiego10");

		} catch (SQLException e) {
//			Loggerj.logError(Throwables.getStackTraceAsString(e));
//			throw new SQLException(Throwables.getStackTraceAsString(e));
			throw new SQLException(e.getMessage());

		}

		return conn;

	}

}
