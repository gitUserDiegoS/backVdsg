package com.log4j;

import java.net.URL;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.helpers.Loader;

public class Loggerj {

	private static Logger log = Logger.getLogger("AdapterRestService");


	/**
	 * Metodo que recibe solo mensaje como log debug
	 * @param inMsg
	 */
	public static void logDebug(String inMsg) {

		basicConfiguration();
		log.debug(" [-] " + "another"+inMsg);
	}

	/**
	 * Metodo que recibe mensaje como log error
	 * @param msg
	 */
	public static void logError(String msg) {
		basicConfiguration();
		log.error(" [-] " + msg);
	}

	/**
	 * Metodo que recibe valor de clase y mensaje 
	 * @param name
	 * @param inMsg
	 */
	public static void logDebug(String name, String inMsg) {
		log=Logger.getLogger(name);
//		Logger.getLogger(name);
		basicConfiguration();
		log.debug(" [-] " + "another" + inMsg);

	}

	/**
	 * Metodo que carga el fichero como recurso si est� en el classpath
	 */
	public static void basicConfiguration() {
		URL url = Loader.getResource("log4j.properties");
		PropertyConfigurator.configure(url);
	}

	

}
