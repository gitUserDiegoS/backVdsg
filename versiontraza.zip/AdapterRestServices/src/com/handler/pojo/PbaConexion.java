package com.handler.pojo;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class PbaConexion {

	public static void main(String[] args) {
		Connection con = null;

		try {
			// TODO Auto-generated method stub

//			cargar driver
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());

//			conectar con la bd
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "oraDiego10");

//			llamada al procedimiento almacenado
			CallableStatement cst = con.prepareCall("{call ObtenerDatosCatalogo (?,?,?)}");

//			parametro del procedimiento almacenado
			int id = 1;
			cst.setInt(1, id);

//			definicion de los tipos de parametros de salida
			cst.registerOutParameter(2, java.sql.Types.INTEGER);
			cst.registerOutParameter(3, java.sql.Types.VARCHAR);

//			ejecucion del procedimiento
			cst.execute();

//			obtencion de la salida del procedimiento
			int operacion = cst.getInt(2);
			String endpoint = cst.getString(3);
			
			System.out.println("ESto es lo que se obtiene del procedimiento---->operacion-->"+operacion+" endpoint-->"+endpoint);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error: " + e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				con.close();
			} catch (SQLException ex) {
				System.out.println("Error: " + ex.getMessage());
			}
		}

	}
}