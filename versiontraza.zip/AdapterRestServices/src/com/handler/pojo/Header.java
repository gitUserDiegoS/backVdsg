package com.handler.pojo;

public class Header {

	
	private String country; 
	private String commerce;
	private String channel;
	private String storeId;
	private String terminalId;
	private String dateReq;
	private String hourReq;
	private String operation;
	
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCommerce() {
		return commerce;
	}
	public void setCommerce(String commerce) {
		this.commerce = commerce;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getStoreId() {
		return storeId;
	}
	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}
	public String getTerminalId() {
		return terminalId;
	}
	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}
	public String getDateReq() {
		return dateReq;
	}
	public void setDateReq(String dateReq) {
		this.dateReq = dateReq;
	}
	public String getHourReq() {
		return hourReq;
	}
	public void setHourReq(String hourReq) {
		this.hourReq = hourReq;
	}
	public String getOperation() {
		return operation;
	}
	public void setOperation(String operation) {
		this.operation = operation;
	}
	
	
	
	
	
}
