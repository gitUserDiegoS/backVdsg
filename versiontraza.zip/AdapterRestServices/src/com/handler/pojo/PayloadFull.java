package com.handler.pojo;

public class PayloadFull {

	private Header loadHead;
	private Body loadBody;
	public Header getLoadHead() {
		return loadHead;
	}
	public void setLoadHead(Header loadHead) {
		this.loadHead = loadHead;
	}
	public Body getLoadBody() {
		return loadBody;
	}
	public void setLoadBody(Body loadBody) {
		this.loadBody = loadBody;
	}
	
	
	
	
	
}
