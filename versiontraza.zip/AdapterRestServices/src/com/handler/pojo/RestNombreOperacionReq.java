package com.handler.pojo;

public class RestNombreOperacionReq {
    private String numeroTienda;
    private String nunmeroSku;
	public String getNumeroTienda() {
		return numeroTienda;
	}
	public void setNumeroTienda(String numeroTienda) {
		this.numeroTienda = numeroTienda;
	}
	public String getNunmeroSku() {
		return nunmeroSku;
	}
	public void setNunmeroSku(String nunmeroSku) {
		this.nunmeroSku = nunmeroSku;
	}
    
    
    
}
