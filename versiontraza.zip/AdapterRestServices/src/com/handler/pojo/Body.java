package com.handler.pojo;

public class Body {

	private RestNombreOperacionReq bodyPayload;

	public RestNombreOperacionReq getBodyPayload() {
		return bodyPayload;
	}

	public void setBodyPayload(RestNombreOperacionReq bodyPayload) {
		this.bodyPayload = bodyPayload;
	}
	
	
	
}
