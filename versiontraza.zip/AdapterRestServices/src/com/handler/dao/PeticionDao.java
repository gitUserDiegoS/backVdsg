package com.handler.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.handler.client.AccesoCliente;
import com.handler.procedures.Consulta;
import com.log4j.Loggerj;

public class PeticionDao {

	private String operation;

	public String getOperation() {
		return operation;
	}

	public void setOperation(String operation) {
		this.operation = operation;
	}

	public PeticionDao() {
		super();
	}

	/**
	 * Metodo que devuelve respuesta de endpoint segun operacion
	 * 
	 * @param payloadFull
	 * @return
	 * @throws Exception, SQLException
	 */
	public String handleRequest(String payloadFull) throws Exception, SQLException {

		String enrutador = "";
		try {

			if (payloadFull.isEmpty()) {

				throw new Exception("No se indica ningun payload a enviar");

			}

			setOperation(tipoOperacion(payloadFull));

			System.out.println("Esto es lo que estoy obteniendo desde clase---->" + getOperation());

			enrutador = new Consulta().leerhcweb(getOperation());

			System.out.println("Ruta a utilizar de consumo (hcweb) --->" + enrutador);

			// obtencion de respuesta segun endpoint
			String respuesta = new AccesoCliente().envioDePayloadpost(enrutador, payloadFull);
			return respuesta;
		} catch (SQLException e) {

			throw new SQLException(e.getMessage());

		}

	}

	/**
	 * Metodo que recibe payload completo para tratar la etiqueta header del json
	 * 
	 * @param payloadHeader
	 * @return operation, para determinar el endpoint a enrutar
	 */
	public String tipoOperacion(String payloadHeader) {

		System.out.println("Payload recibido --->" + payloadHeader);

		// convierte string a hashmap
		HashMap<String, Object> result;
		result = parseObjectToHashMap(payloadHeader);

		// Obtencion header del payload recibido
		Object objectoObtenido = result.get("Header");

		// conversion de objeto header a hashmap para obtener el tipo de operacion
		HashMap<String, Object> map = (HashMap<String, Object>) objectoObtenido;
		System.out.println(map);
		setOperation((String) map.get("operation"));

		return operation;
	}

	/**
	 * Metodo que recibe payload y obtiene etiqueta body
	 * 
	 * @param payloadGeneric
	 * @return
	 */
	public String obtenerBody(String payloadGeneric) {
		System.out.println("Payload recibido --->" + payloadGeneric);

		// Obtencion payload recibido
		HashMap<String, Object> bodyResult;
		Object objetoBody = new Object();
		HashMap<String, String> mapBody = new HashMap<>();
		bodyResult = parseObjectToHashMap(payloadGeneric);

		// obtencion de etiqueta body a objeto generico
		objetoBody = bodyResult.get("Body");
		mapBody = (HashMap<String, String>) objetoBody;

		// conversion de hashmap a json para enviar request
		Gson gson = new Gson();
		String jsonToString = gson.toJson(objetoBody);

		System.out.println("Esto es lo que devuelve con libreria Gson---->" + jsonToString);

		System.out.println("datos body-------------->" + mapBody);

		return mapBody.toString();

	}

	/**
	 * Metodo que pasa payload completo a hashmap
	 * 
	 * @param payloadGeneric
	 * @return hashmap generalHash
	 */
	public HashMap<String, Object> parseObjectToHashMap(String payloadGeneric) {

//		obtencion de payload para convertir a objeto generico a hashMap
		HashMap<String, Object> generalHash = new HashMap<>();

//		Object objetoBody = new Object();

//		HashMap<String, String> mapBody = new HashMap<>();

		try {
//			pasa string payload a hashmap bodyresult
			generalHash = new ObjectMapper().readValue(payloadGeneric, HashMap.class);
		} catch (JsonParseException e) {
			Loggerj.logError(e.getMessage());
			e.printStackTrace();
		} catch (JsonMappingException e) {
			Loggerj.logError(e.getMessage());
			e.printStackTrace();
		} catch (IOException e) {
			Loggerj.logError(e.getMessage());
			e.printStackTrace();
		}
		return generalHash;

	}

	/**
	 * Metodo que trata el mensaje de la excepcion, si viene con comillas se quitan
	 * para devolver con formato el mensaje
	 * 
	 * @param exc
	 * @return string formateado
	 */
	public String manageException(String exc) {
		String msg = "";
		if (exc.contains("\"")) {
			msg = exc.replace("\"", " ").trim();

		} else {
			msg = exc;

		}

		return msg;
	}

	/**
	 * Metodo que registra la trazabilidad del evento en base de datos
	 * 
	 * @param payload
	 * @param tipoDeEvento
	 * @return
	 * @throws SQLException
	 */
	public boolean registrarEvento(String payload, String msgResp, String msg, boolean tipoDeEvento)
			throws SQLException {
		boolean satisfactorio = false;
		try {

			// si es true, registra traza flujo normal
			if (tipoDeEvento == true) {

				new Consulta().inserthcwebDos(Integer.valueOf(AccesoCliente.getEstadoApersistir()),
						new Date().toString(), new PeticionDao().tipoOperacion(payload), payload, msgResp);

			} else {// sino registra flujo con excepcion
				new Consulta().inserthcwebDos(500, new Date().toString(),
						payload.isEmpty() ? "No registra" : new PeticionDao().tipoOperacion(payload),
						payload.isEmpty() ? "No resgistra" : payload,
						"{\r\n" + "    \"RestConsultarSKUResp\": {\r\n" + "        \"RespuestaCodigo\": \"1\",\r\n"
								+ "        \"RespuestaMensaje\": \"" + msg + "\"\r\n" + "    }\r\n" + "}");

			}

		} catch (NumberFormatException e) {

			throw new NumberFormatException("Number format exception "+e.getMessage());
		} catch (SQLException e) {

			throw new SQLException(e.getMessage());
		}
		return satisfactorio;

	}

}
