package com.handler.annotation;


public @interface JWTTokenNeeded {

}
