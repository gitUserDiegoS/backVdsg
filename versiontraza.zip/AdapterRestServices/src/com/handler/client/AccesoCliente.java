package com.handler.client;

import javax.ws.rs.core.Response;

import com.log4j.Loggerj;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class AccesoCliente {

	static String estadoApersistir;

	public static String getEstadoApersistir() {
		return estadoApersistir;
	}

	public static void setEstadoApersistir(String estadoApersistir) {
		AccesoCliente.estadoApersistir = estadoApersistir;
	}

	// public static void main(String[] args) {
	public String devuelveRespuesta(String ruta) {
//		Client cliente = ClientBuilder.newClient();
//		String json = cliente.target("http://localhost:9190/ProductoSw/users").request(MediaType.APPLICATION_JSON_TYPE)
//				.get().toString();
//		System.out.println("Lo que obtiene del servicio--->" + json);

		Client client = Client.create();
		System.out.println("endpoint a enrutar ---->" + ruta);
//		WebResource resource = client.resource("http://localhost:9190/ProductoSw/users");
		WebResource resource = client.resource(ruta);
//		

		ClientResponse response = resource.accept("application/json").get(ClientResponse.class);
		String codeStatus = String.valueOf(response.getStatus());
		estadoApersistir = codeStatus;
		if (response.getStatus() != 200) {
			throw new RuntimeException("Fall� : HTTP error code:" + response.getStatus());

		} else {

			String output = response.getEntity(String.class);
			System.out.println("Esto es lo que obtiene--->" + output);
//		return output;
			return output;
		}
	}

	public String envioDePayloadpost(String ruta, String payload) {

		Client client = Client.create();

		WebResource resource = client.resource(ruta);

		String input = payload;

		ClientResponse response = resource.type("application/json").post(ClientResponse.class, input);

		String codeStatus = String.valueOf(response.getStatus());
		estadoApersistir = codeStatus;

		if (response.getStatus() != 200) {
			Loggerj.logError("fall� response, en acceso a cliente " + codeStatus);
			throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());

		}

		System.out.println("Output from server ... \n");

		String output = response.getEntity(String.class);
		System.out.println(output);

		return output;

	}

}
