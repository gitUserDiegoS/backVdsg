package com.handler.procedures;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;

import com.handler.connection.Connector;
import com.log4j.Loggerj;

public class Consulta {

	private Connection con;
	private CallableStatement cst;

	public Connection getCon() {
		return con;
	}

	public void setCon(Connection con) {
		this.con = con;
	}

	public CallableStatement getCst() {
		return cst;
	}

	public void setCst(CallableStatement cst) {
		this.cst = cst;
	}

	public String leerhcweb(String oper) throws SQLException {

		con = null;

		Connector hcWeb = new Connector();
		con = hcWeb.Conectar();

		int operacion = 0;
		String endpoint = "";

		while (con == null) {
			hcWeb = new Connector();
			con = hcWeb.Conectar();
		}

		try {
//			llamada al procedimiento almacenado

			cst = con.prepareCall("{call ObtenerDatosCatalogo (?,?)}");

//			parametro del procedimiento almacenado
//			int id = 1;
			cst.setString(1, oper);

//			definicion de los tipos de parametros de salida			
			cst.registerOutParameter(2, java.sql.Types.VARCHAR);

//			ejecucion del procedimiento
			cst.execute();

//			obtencion de la salida del procedimiento			
			endpoint = cst.getString(2);

			System.out.println("ESto es lo que se obtiene del procedimiento---->operacion-->" + operacion
					+ " endpoint-->" + endpoint);

			System.out.println("modular lo que obtiene-->"
					+ claseOrigen(new String(Thread.currentThread().getStackTrace()[1].getMethodName()),
							new String(Thread.currentThread().getStackTrace()[1].getClassName())));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("clase " + e.getMessage());

//			Loggerj.logError(e.getMessage());
			throw new SQLException("Error no data found - " + e.getMessage());

//			e.printStackTrace();
		} finally {
			try {
				con.close();
				cst.close();

			} catch (SQLException ex) {
				System.out.println("Error: " + ex.getMessage());
//				Loggerj.logError(ex.getMessage());
				throw new SQLException("Error no data found - " + ex.getMessage());
			}
		}
		return endpoint;

	}

	public String inserthcweb(int codigo, String nombre, String fecha) throws SQLException {

		con = null;

		Connector hcWeb = new Connector();
		con = hcWeb.Conectar();

		int operacion = 0;
		String endpoint = "";

		while (con == null) {
			hcWeb = new Connector();
			con = hcWeb.Conectar();
		}

		try {
//			llamada al procedimiento almacenado

			cst = con.prepareCall("{call registratraza (?,?,?)}");

//			parametro del procedimiento almacenado
//			int id = 1;
			cst.setInt(1, codigo);
			cst.setString(2, nombre);
			cst.setString(3, fecha);

//			ejecucion del procedimiento
			cst.execute();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new SQLException("Error al registrar " + e.getMessage());

//			System.out.println("Error: " + e.getMessage());

//			e.printStackTrace();
		} finally {
			try {
				con.close();
				cst.close();

			} catch (SQLException ex) {
				System.out.println("Error: " + ex.getMessage());
			}
		}
		return "----ESto es lo que se obtiene del procedimiento---->operacion-->" + operacion + " endpoint-->"
				+ endpoint;

	}

//	opccion dos de tabla
	public boolean inserthcwebDos(int codigo, String fecha, String operacion, String pointrequest, String pointresponse)
			throws SQLException {

		con = null;
		boolean satisfactorio = false;

		Connector hcWeb = new Connector();
		con = hcWeb.Conectar();

//		int operacion = 0;
		String endpoint = "";

		while (con == null) {
			hcWeb = new Connector();
			con = hcWeb.Conectar();
		}

		try {
//			llamada al procedimiento almacenado

			cst = con.prepareCall("{call registratrazados (?,?,?,?,?)}");

//			parametro del procedimiento almacenado
//			int id = 1;
			cst.setInt(1, codigo);
			cst.setString(2, fecha);
			cst.setString(3, operacion);
			cst.setString(4, pointrequest);
			cst.setString(5, pointresponse);

//			ejecucion del procedimiento
			cst.execute();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error: " + e.getMessage());
//			e.printStackTrace();
			throw new SQLException("Error: " + e.getMessage());

		} finally {
			try {
				con.close();
				cst.close();

			} catch (SQLException ex) {
				throw new SQLException("Error: " + ex.getMessage());
			}
		}
		return satisfactorio;

	}

	public String claseOrigen(String nameMethod, String nameClass) {
		String sMethodName = nameMethod;
		String sClassName = nameClass;
		return "Class - [" + sClassName + "] Metodo - [" + sMethodName + "]";
	}

}
